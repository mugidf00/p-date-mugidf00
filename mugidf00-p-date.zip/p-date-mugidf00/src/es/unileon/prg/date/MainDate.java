package es.unileon.prg.date;

public class MainDate {

	public static void main(String[] args) {

		Date today;
		
		//Date tomorrow;

		try {
			//today prueba: today = new Date(30, 4, 2017);
			//mes 14
			//day 99
			today = new Date(30, 4, 2017);
			
		//	tomorrow = new Date(31,4,2017);
			
			System.out.println(today.toString());
			
		} catch (DateException e) {
			
			System.out.println(e.getMessage());
			
		}

	}

}
