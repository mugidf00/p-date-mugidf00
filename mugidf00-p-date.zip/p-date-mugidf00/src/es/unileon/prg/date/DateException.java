package es.unileon.prg.date;

public class DateException extends Exception {
	
	public DateException(String message){
		
		super(message);

	}

}
